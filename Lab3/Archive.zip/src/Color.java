/**
 * Represents the color of the chess piece, white or black.
 */
public enum Color {
  WHITE, BLACK
}
