/**
 * Tests for the Bishop chess piece implementation.
 */
public class BishopTest extends AbstractChessPieceTest {

  /**
   * Creates a new Bishop piece with the given position and color.
   *
   * @param row the row position
   * @param col the column position
   * @param color the piece color
   * @return a new Bishop instance
   */
  @Override
  protected ChessPiece createPiece(int row, int col, Color color) {
    return new Bishop(row, col, color);
  }

  /**
   * Calculates and marks valid diagonal moves for a bishop at the given position.
   * Updates the results array to indicate all valid moves from the current position,
   * taking into account the board boundaries.
   *
   * @param row the current row position of the bishop
   * @param col the current column position of the bishop
   */
  @Override
  protected void setupResults(int row, int col) {
    // Calculate all possible diagonal moves in all four directions
    for (int i = 0; i < 8; i++) {
      // Down-right diagonal
      if ((row + i) < 8 && (col + i) < 8) {
        results[row + i][col + i] = true;
      }
      // Down-left diagonal
      if ((row + i) < 8 && col >= i) {
        results[row + i][col - i] = true;
      }
      // Up-right diagonal
      if (row >= i && (col + i) < 8) {
        results[row - i][col + i] = true;
      }
      // Up-left diagonal
      if (row >= i && col >= i) {
        results[row - i][col - i] = true;
      }
    }
  }
}